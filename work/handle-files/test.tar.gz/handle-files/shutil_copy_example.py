import shutil
import os

shutil.copy('hello.py', 'welcome.py')
print("Copy Successful")
