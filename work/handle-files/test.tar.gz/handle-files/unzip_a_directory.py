import shutil

shutil.unpack_archive('work.zip', 'work')
